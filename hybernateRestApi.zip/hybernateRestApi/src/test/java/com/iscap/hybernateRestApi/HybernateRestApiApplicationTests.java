package com.iscap.hybernateRestApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HybernateRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
