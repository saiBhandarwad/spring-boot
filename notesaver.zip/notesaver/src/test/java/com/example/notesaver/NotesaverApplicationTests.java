package com.example.notesaver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotesaverApplicationTests {

	@Test
	void contextLoads() {
	}

}
